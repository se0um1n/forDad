import streamlit as st
import random
import json

st.set_page_config(page_title="운빨 인생", page_icon="🎲", layout="centered")

# (제목, 설명, [선택명, 비용, [(확률 가중치, 결과 설명, 변화량)]])
EVENTS = [
("친구의 창업 제안", "배달앱 정도는 우리도 만들 수 있지 않을까?", [
("500만 원 투자",500,[(35,"사업 대박! 친구가 수익을 나눠줬다.",dict(money=1800,happy=12,bond=8)),(65,"사업은 망했다. 사무실 의자는 건졌다.",dict(happy=-5,bond=-8))]),
("응원만 하기",0,[(100,"친구의 발표 자료에 하트를 눌러줬다.",dict(bond=3,happy=2))])]),
("한정판 운동화", "마지막 한 켤레가 내 사이즈다.", [
("30만 원에 구매",30,[(100,"신발장을 볼 때마다 행복하다.",dict(happy=10))]),
("참기",0,[(100,"잔고를 보고 마음의 평화를 얻었다.",dict(happy=2))])]),
("주말의 선택", "아무 일정도 없는 토요일 아침이다.", [
("운동하기",0,[(85,"생각보다 상쾌하다.",dict(health=10,happy=3)),(15,"무리해서 근육통이 왔다.",dict(health=-3,happy=1))]),
("소파와 합체",0,[(100,"자동재생이 나보다 부지런하다.",dict(happy=8,health=-4))])]),
("뜻밖의 보너스", "이번 달은 통장이 조금 든든하다.", [
("저축",0,[(100,"차곡차곡 모았다.",dict(money=200,happy=2))]),
("가족과 여행",0,[(100,"보너스를 여행에 썼다. 사진은 남았다.",dict(bond=12,happy=12,health=3))])]),
("수상한 투자 정보", "단톡방이 지금 아니면 늦는다고 한다.", [
("200만 원 투자",200,[(20,"운 좋게 크게 올랐다.",dict(money=1000,happy=10)),(80,"단톡방 이름이 장기투자 모임으로 바뀌었다.",dict(happy=-8))]),
("방 나가기",0,[(100,"알림이 줄어 마음이 편하다.",dict(happy=5))])]),
("동창회 초대", "오랜만에 얼굴을 볼까?", [
("참석",10,[(75,"옛 추억에 웃었다.",dict(bond=12,happy=5)),(25,"보험 상담을 두 시간 받았다.",dict(bond=-3,happy=-4))]),
("집에서 쉬기",0,[(100,"푹 쉬었다.",dict(health=6,happy=3,bond=-2))])]),
("길고양이의 눈빛", "집 앞 고양이가 나를 따라온다.", [
("구조 상담 후 입양 준비",50,[(100,"돌봄 책임이 생겼다. 집에는 온기가 생겼다.",dict(happy=13,bond=5,health=-2,cat=1))]),
("보호단체에 상담 요청",0,[(100,"도움을 받을 방법을 함께 찾았다.",dict(happy=4,bond=3))])]),
("야근 제안", "이번 프로젝트는 수당이 나온다.", [
("야근하기",0,[(100,"통장은 웃고 허리는 운다.",dict(money=180,health=-10,happy=-4))]),
("정시 퇴근",0,[(100,"저녁 하늘이 이렇게 예뻤나.",dict(health=5,happy=7))])]),
("복권 판매점", "꿈에서 돼지를 봤던 것 같기도 하다.", [
("1만 원 구매",1,[(2,"소박하지만 놀라운 당첨!",dict(money=500,happy=15)),(98,"다음 주에도 출근이다.",dict(happy=1))]),
("그냥 지나가기",0,[(100,"확실하게 1만 원을 지켰다.",dict(happy=1))])]),
("새 취미 발견", "도예 수업 광고가 눈에 들어왔다.", [
("등록하기",40,[(100,"삐뚤어진 컵과 새 친구를 얻었다.",dict(happy=10,bond=7))]),
("무료 영상으로 배우기",0,[(70,"제법 재미있는 취미가 됐다.",dict(happy=6)),(30,"영상만 저장했다.",dict(happy=1))])]),
("친구의 부탁", "급한 일이 생겼다며 도움을 청한다.", [
("시간 내어 돕기",0,[(100,"고맙다는 말을 오래 기억할 것 같다.",dict(bond=12,health=-3,happy=4))]),
("이번에는 거절",0,[(100,"내 일정을 지켰다.",dict(health=4,bond=-4))])]),
("중고 거래", "창고에 안 쓰는 물건이 쌓여 있다.", [
("정리해서 판매",0,[(80,"집도 통장도 가벼워지고 든든해졌다.",dict(money=70,happy=6,health=-2)),(20,"약속 장소에 아무도 오지 않았다.",dict(happy=-4))]),
("추억으로 간직",0,[(100,"추억이 공간을 차지한다.",dict(happy=3))])]),
("밤 12시 배달앱", "추천 메뉴가 너무 정확하다.", [
("치킨 주문",3,[(100,"바삭함은 배신하지 않았다.",dict(happy=8,health=-4))]),
("물 마시고 자기",0,[(100,"아침의 내가 고마워했다.",dict(health=6,happy=1))])]),
("작은 사업 아이디어", "직접 만든 물건을 팔아볼까?", [
("100만 원으로 시작",100,[(45,"첫 주문부터 입소문이 났다.",dict(money=450,happy=9,business=1)),(55,"재고가 집 안 인테리어가 됐다.",dict(happy=-5,business=1))]),
("취미로 남기기",0,[(100,"마감 없는 창작은 편안하다.",dict(happy=6))])]),
("건강검진의 조언", "생활 습관을 조금 바꾸면 좋겠다고 한다.", [
("꾸준히 걷기",0,[(100,"가까운 거리는 걸어 다녔다.",dict(health=12,happy=3))]),
("일단 미루기",0,[(100,"시간은 벌었지만 몸은 조금 지쳤다.",dict(money=50,health=-8))])]),
("휴가 계획", "잠시 일상에서 벗어날 기회다.", [
("혼자 여행",80,[(100,"길을 잃었지만 기분은 찾았다.",dict(happy=14,health=5))]),
("동네 산책",0,[(100,"집 근처에도 처음 보는 길이 있었다.",dict(happy=6,health=6))])]),
("자격증 도전", "퇴근 후 공부를 해볼까?", [
("수강 신청",50,[(60,"합격! 선택지가 조금 넓어졌다.",dict(money=250,happy=8,health=-4)),(40,"이번에는 아쉽게 불합격.",dict(happy=-4,health=-3))]),
("다음 기회로",0,[(100,"지금의 여유를 택했다.",dict(happy=4,health=3))])]),
("뜻밖의 재회", "예전 친구에게 메시지가 왔다.", [
("만나기",5,[(100,"대화가 어제의 연속 같았다.",dict(bond=10,happy=6))]),
("안부만 전하기",0,[(100,"짧지만 반가운 대화를 나눴다.",dict(bond=3,happy=2))])]),
("휴대폰의 유혹", "새 모델의 카메라가 엄청나다고 한다.", [
("교체하기",120,[(100,"달 사진을 열두 장 찍었다.",dict(happy=10))]),
("기존 폰 더 쓰기",0,[(100,"생각보다 더 쓸 만하다.",dict(happy=4))])]),
("동네 축제", "골목에 음악 소리가 들린다.", [
("구경 가기",2,[(100,"떡볶이와 어설픈 공연이 의외로 좋았다.",dict(happy=8,bond=5))]),
("조용히 독서",0,[(100,"마음에 드는 문장을 발견했다.",dict(happy=6,health=2))])]),
]
ENDINGS={"cat":"🐈 고양이에게 간택된 자", "business":"🚀 연쇄 창업가", "rich":"🏦 통장만 따뜻한 사람", "social":"🤝 동네 인기인", "happy":"🌼 마음만은 부자", "balance":"⚖️ 균형의 달인", "retire":"🛌 쉼이 필요한 시간", "ordinary":"🍵 무난해서 귀한 삶"}

def new_game():
    return dict(age=20,money=500,health=65,happy=50,bond=50,cat=0,business=0,turn=0,deck=random.sample(range(len(EVENTS)),len(EVENTS)),result=None,logs=[],done=False)

def apply_choice(g, cost, result):
    g['money']-=cost
    text, delta=result
    for k,v in delta.items():
        g[k]+=v
        if k in ('health','happy','bond'): g[k]=max(0,min(100,g[k]))
    g['result']={'text':text,'delta':delta,'cost':cost}
    g['logs'].append({'age':g['age'],'text':text})

def ending(g):
    if g['health']<=0:return 'retire'
    if g['cat']:return 'cat'
    if g['business']>=2:return 'business'
    if g['money']>=2000 and (g['happy']<60 or g['bond']<60):return 'rich'
    if g['bond']>=85:return 'social'
    if g['happy']>=85:return 'happy'
    if min(g['health'],g['happy'],g['bond'])>=65:return 'balance'
    return 'ordinary'

def reset():
    st.session_state.g=new_game()

if 'g' not in st.session_state:reset()
if 'collection' not in st.session_state:st.session_state.collection=[]
g=st.session_state.g
st.title('🎲 운빨 인생')
st.caption('선택은 내가, 결과는 운빨. 20살부터 20번의 선택으로 완성하는 인생.')
with st.sidebar:
    st.header('게임 안내')
    st.write('매년 선택 한 번! 선택 후 결과를 확인하고 다음 해로 넘어가세요. 40살에 결산하며 건강이 0이면 일찍 쉬게 됩니다.')
    st.caption('게임 속 확률은 오락을 위한 설정이며 현실 투자·건강 조언이 아닙니다.')
    if st.button('새 인생 시작',use_container_width=True):
        reset(); st.rerun()
    st.divider()
    st.write('💾 새로고침 전에 저장하세요. 저장 파일에는 현재 게임과 엔딩 도감이 들어갑니다.')
    save={'version':1,'game':g,'collection':st.session_state.collection}
    st.download_button('현재 진행 저장',json.dumps(save,ensure_ascii=False,indent=2),file_name='life_save.json',mime='application/json')
    upload=st.file_uploader('저장 불러오기',type=['json'])
    if st.button('불러오기 적용',disabled=upload is None):
        try:
            data=json.loads(upload.getvalue())
            h=data['game']
            assert data['version']==1
            assert isinstance(h,dict) and set(h)==set(new_game())
            assert all(type(h[k]) is int for k in ('age','money','health','happy','bond','cat','business','turn'))
            assert 0<=h['turn']<20 and h['age']==20+h['turn']+int(h['done'])
            assert all(0<=h[k]<=100 for k in ('health','happy','bond')) and h['money']>=0
            assert sorted(h['deck'])==list(range(20)) and type(h['done']) is bool
            assert isinstance(h['logs'],list) and len(h['logs'])<=20
            assert all(isinstance(x,dict) and isinstance(x.get('age'),int) and isinstance(x.get('text'),str) for x in h['logs'])
            assert h['result'] is None or (isinstance(h['result'],dict) and isinstance(h['result'].get('text'),str) and isinstance(h['result'].get('delta'),dict) and type(h['result'].get('cost')) is int and all(k in ('money','health','happy','bond','cat','business') and type(v) is int for k,v in h['result']['delta'].items()))
            assert isinstance(data['collection'],list) and all(x in ENDINGS for x in data['collection'])
            st.session_state.g=h;st.session_state.collection=data['collection'];st.rerun()
        except (ValueError,KeyError,TypeError,AssertionError,AttributeError):st.error('호환되는 저장 파일이 아닙니다.')
cols=st.columns(4)
for col,label,key in zip(cols,['💰 돈 (만원)','❤️ 건강','😊 행복','🤝 관계'],['money','health','happy','bond']):col.metric(label,g[key])
st.progress(min(1,(g['turn']+int(g['done']))/20),text=f"{g['age']}살 · {min(20,g['turn']+int(g['done']))}/20년 완료")
if g['done']:
    e=ending(g)
    if e not in st.session_state.collection:st.session_state.collection.append(e)
    st.success('인생 결산')
    st.header(ENDINGS[e])
    st.write(f"{g['age']}살의 당신. 돈뿐 아니라 행복, 관계, 건강과 선택의 흔적이 이 엔딩을 만들었습니다.")
    if st.button('다른 인생 살아보기',type='primary'):reset();st.rerun()
elif g['result'] is not None:
    r=g['result'];st.subheader('올해의 결과');st.info(r['text'])
    labels={'money':'돈(만원)','health':'건강','happy':'행복','bond':'관계','cat':'입양','business':'창업 횟수'}
    d=dict(r['delta']);d['money']=d.get('money',0)-r['cost']
    st.caption(' · '.join(f'{labels[k]} {v:+d}' for k,v in d.items() if v))
    if st.button('인생 결산 보기' if g['turn']==19 or g['health']==0 else '다음 해로 →',type='primary'):
        g['age']+=1
        if g['turn']==19 or g['health']==0:g['done']=True
        else:g['turn']+=1;g['result']=None
        st.rerun()
else:
    title,desc,choices=EVENTS[g['deck'][g['turn']]]
    st.subheader(f"{g['age']}살 — {title}");st.write(desc)
    for i,(label,cost,outcomes) in enumerate(choices):
        st.caption(' / '.join(f'{weight}%: {text}' for weight,text,delta in outcomes))
        if st.button(label,key=f"choice_{g['turn']}_{i}",disabled=g['money']<cost,use_container_width=True):
            chosen=random.choices(outcomes,weights=[o[0] for o in outcomes],k=1)[0]
            apply_choice(g,cost,(chosen[1],chosen[2]));st.rerun()
        if g['money']<cost:st.caption('잔액이 부족합니다.')
with st.expander('📜 나의 인생 기록',expanded=False):
    if not g['logs']:st.write('아직은 백지인 인생입니다.')
    for log in reversed(g['logs']):st.write(f"**{log['age']}살** · {log['text']}")
with st.expander(f"🏆 엔딩 도감 ({len(st.session_state.collection)}/{len(ENDINGS)})"):
    for k,v in ENDINGS.items():st.write(v if k in st.session_state.collection else '🔒 미발견 엔딩')
    st.caption('여러 조건이 겹치면 조기 은퇴 → 입양 → 창업 → 자산 → 관계 → 행복 → 균형 순으로 판정합니다. 도감도 저장 파일로 보관하세요.')
